const { createHmac, randomInt, timingSafeEqual } = require("node:crypto");
const admin = require("firebase-admin");
const { defineSecret, defineString } = require("firebase-functions/params");
const { HttpsError, onCall } = require("firebase-functions/v2/https");

admin.initializeApp({ storageBucket: "qrscannereapihs.firebasestorage.app" });

const emailjsPrivateKey = defineSecret("EMAILJS_PRIVATE_KEY");
const otpHmacSecret = defineSecret("OTP_HMAC_SECRET");
const emailjsPublicKey = defineString("EMAILJS_PUBLIC_KEY");
const emailjsServiceId = defineString("EMAILJS_SERVICE_ID");
const emailjsOtpTemplateId = defineString("EMAILJS_OTP_TEMPLATE_ID");
const region = "us-central1";
const codeLifetimeMs = 10 * 60 * 1000;
const rateWindowMs = 60 * 60 * 1000;
const emailHourlyLimit = 4;
const ipHourlyLimit = 15;
const resendDelayMs = 60 * 1000;
const maxCodeAttempts = 5;
const maxSchoolIdImageBytes = 550 * 1024;

function getEmail(data) {
  const email = typeof data?.email === "string" ? data.email.trim().toLowerCase() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new HttpsError("invalid-argument", "Enter a valid email address.");
  }
  return email;
}

function getSecretHash(email) {
  return createHmac("sha256", otpHmacSecret.value()).update(email).digest("hex");
}

function getCodeHash(email, code) {
  return createHmac("sha256", otpHmacSecret.value()).update(`${email}:${code}`).digest("hex");
}

function createRateData(previous, now, limit, windowMs) {
  const windowStart = Number(previous?.windowStart) || 0;
  const freshWindow = now - windowStart >= windowMs;
  const count = freshWindow ? 0 : Number(previous?.count) || 0;
  const nextAllowedAt = freshWindow ? 0 : Number(previous?.nextAllowedAt) || 0;
  if (nextAllowedAt > now || count >= limit) {
    throw new HttpsError("resource-exhausted", "Wait before requesting another verification code.");
  }
  return {
    count: count + 1,
    windowStart: freshWindow ? now : windowStart,
    nextAllowedAt: now + resendDelayMs,
    expiresAt: admin.firestore.Timestamp.fromMillis(now + windowMs),
  };
}

async function sendEmail(email, passcode) {
  const publicKey = emailjsPublicKey.value();
  const serviceId = emailjsServiceId.value();
  const otpTemplateId = emailjsOtpTemplateId.value();
  if (!publicKey || !serviceId || !otpTemplateId) {
    throw new HttpsError("failed-precondition", "EmailJS OTP template configuration is incomplete.");
  }

  const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    signal: AbortSignal.timeout(15000),
    body: JSON.stringify({
      service_id: serviceId,
      template_id: otpTemplateId,
      user_id: publicKey,
      accessToken: emailjsPrivateKey.value(),
      template_params: { email, passcode },
    }),
  });

  if (!response.ok) {
    throw new HttpsError("unavailable", "EmailJS could not send the verification email.");
  }
}

exports.requestSignupOtp = onCall(
  {
    region,
    enforceAppCheck: true,
    secrets: [emailjsPrivateKey, otpHmacSecret],
  },
  async (request) => {
    const email = getEmail(request.data);
    try {
      await admin.auth().getUserByEmail(email);
      throw new HttpsError("already-exists", "An account already exists for this email.");
    } catch (error) {
      if (error instanceof HttpsError) throw error;
      if (error.code !== "auth/user-not-found") throw error;
    }

    const now = Date.now();
    const emailHash = getSecretHash(email);
    const requestIp = request.rawRequest.ip || "unknown";
    const ipHash = getSecretHash(`ip:${requestIp}`);
    const firestore = admin.firestore();
    const otpRef = firestore.collection("signupOtps").doc(emailHash);
    const emailRateRef = firestore.collection("signupRateLimits").doc(`email_${emailHash}`);
    const ipRateRef = firestore.collection("signupRateLimits").doc(`ip_${ipHash}`);
    const passcode = String(randomInt(0, 1_000_000)).padStart(6, "0");

    await firestore.runTransaction(async (transaction) => {
      const [emailRate, ipRate] = await Promise.all([
        transaction.get(emailRateRef),
        transaction.get(ipRateRef),
      ]);
      transaction.set(emailRateRef, createRateData(emailRate.data(), now, emailHourlyLimit, rateWindowMs));
      transaction.set(ipRateRef, createRateData(ipRate.data(), now, ipHourlyLimit, rateWindowMs));
      transaction.set(otpRef, {
        codeHash: getCodeHash(email, passcode),
        createdAt: admin.firestore.Timestamp.fromMillis(now),
        expiresAt: admin.firestore.Timestamp.fromMillis(now + codeLifetimeMs),
        attempts: 0,
      });
    });

    try {
      await sendEmail(email, passcode);
    } catch (error) {
      await otpRef.delete();
      throw error;
    }

    return { sent: true, expiresInSeconds: codeLifetimeMs / 1000 };
  },
);

exports.verifySignupOtp = onCall(
  {
    region,
    enforceAppCheck: true,
    secrets: [otpHmacSecret],
  },
  async (request) => {
    const email = getEmail(request.data);
    const passcode = typeof request.data?.passcode === "string" ? request.data.passcode.trim() : "";
    const password = typeof request.data?.password === "string" ? request.data.password : "";
    const fullName = typeof request.data?.fullName === "string" ? request.data.fullName.trim() : "";
    const lrn = typeof request.data?.lrn === "string" ? request.data.lrn.trim() : "";
    const confirmLrn = typeof request.data?.confirmLrn === "string" ? request.data.confirmLrn.trim() : "";
    const schoolIdConsent = request.data?.schoolIdConsent === true;
    const schoolIdImageBase64 = typeof request.data?.schoolIdImage === "string" ? request.data.schoolIdImage : "";

    if (!/^\d{6}$/.test(passcode)) {
      throw new HttpsError("invalid-argument", "Enter the six-digit email verification code.");
    }
    if (request.data?.role !== "student") {
      throw new HttpsError("permission-denied", "Student accounts can be registered here. Contact an administrator for teacher access.");
    }
    if (password.length < 8 || password.length > 128) {
      throw new HttpsError("invalid-argument", "Password must be between 8 and 128 characters.");
    }
    if (fullName.length < 3 || fullName.length > 120) {
      throw new HttpsError("invalid-argument", "Enter a valid full name.");
    }
    if (!/^\d{12}$/.test(lrn) || lrn !== confirmLrn) {
      throw new HttpsError("invalid-argument", "The two 12-digit LRNs must match.");
    }
    if (!schoolIdConsent) {
      throw new HttpsError("invalid-argument", "Consent is required to store the School ID image for administrator review.");
    }
    if (
      !schoolIdImageBase64 ||
      schoolIdImageBase64.length > Math.ceil(maxSchoolIdImageBytes / 3) * 4 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(schoolIdImageBase64)
    ) {
      throw new HttpsError("invalid-argument", "Upload a valid School ID image no larger than 550 KB.");
    }
    const schoolIdImage = Buffer.from(schoolIdImageBase64, "base64");
    if (
      schoolIdImage.length === 0 ||
      schoolIdImage.length > maxSchoolIdImageBytes ||
      schoolIdImage.toString("base64") !== schoolIdImageBase64 ||
      schoolIdImage[0] !== 0xff ||
      schoolIdImage[1] !== 0xd8 ||
      schoolIdImage[2] !== 0xff
    ) {
      throw new HttpsError("invalid-argument", "The School ID image must be a valid compressed JPEG file under 550 KB.");
    }

    const firestore = admin.firestore();
    const otpRef = firestore.collection("signupOtps").doc(getSecretHash(email));
    const now = Date.now();
    const verified = await firestore.runTransaction(async (transaction) => {
      const snapshot = await transaction.get(otpRef);
      const record = snapshot.data();
      if (!record || record.expiresAt.toMillis() <= now || record.attempts >= maxCodeAttempts) {
        if (record) transaction.delete(otpRef);
        return false;
      }

      const submittedHash = Buffer.from(getCodeHash(email, passcode), "hex");
      const expectedHash = Buffer.from(record.codeHash, "hex");
      const matches = submittedHash.length === expectedHash.length &&
        timingSafeEqual(submittedHash, expectedHash);
      if (!matches) {
        const attempts = record.attempts + 1;
        if (attempts >= maxCodeAttempts) transaction.delete(otpRef);
        else transaction.update(otpRef, { attempts });
        return false;
      }

      transaction.delete(otpRef);
      return true;
    });

    if (!verified) {
      throw new HttpsError("invalid-argument", "The verification code is invalid or expired. Request a new code.");
    }

    let user;
    let schoolIdFile;
    try {
      user = await admin.auth().createUser({
        email,
        password,
        displayName: fullName,
        emailVerified: true,
      });
      await admin.auth().setCustomUserClaims(user.uid, { role: "student", lrn });
      schoolIdFile = admin.storage().bucket().file(`student-id-review/${user.uid}/school-id.jpg`);
      await schoolIdFile.save(schoolIdImage, {
        resumable: false,
        metadata: {
          contentType: "image/jpeg",
          cacheControl: "private, no-store, max-age=0",
        },
      });
      const customToken = await admin.auth().createCustomToken(user.uid, { role: "student", lrn });
      return {
        customToken,
        student: { name: fullName, lrn, email, qrValue: `EAPIHS-LRN-${lrn}` },
      };
    } catch (error) {
      if (schoolIdFile) {
        try {
          await schoolIdFile.delete({ ignoreNotFound: true });
        } catch {
          console.error("Could not remove incomplete student ID upload.");
        }
      }
      if (user?.uid) {
        try {
          await admin.auth().deleteUser(user.uid);
        } catch {
          console.error("Could not remove incomplete student account.");
        }
      }
      if (error.code === "auth/email-already-exists") {
        throw new HttpsError("already-exists", "An account already exists for this email.");
      }
      throw new HttpsError("internal", "Could not create the account. Request a new code and try again.");
    }
  },
);
