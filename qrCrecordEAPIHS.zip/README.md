# EAPIHS-RECORD

## Account settings and identity

Student signup requires an email OTP delivered by Firebase Cloud Functions, a matching pair of 12-digit LRN entries, and a School ID image. The image is compressed to JPEG (maximum 550 KB) and stored in a private Firebase Storage path for administrator review; only accounts with the trusted `admin` role claim can read it through Firebase Storage rules. The upload check verifies that the file is a valid JPEG after compression, not that the ID is genuine or that its details match the entered LRN; signup does not wait for admin approval. The sign-in page also offers Firebase's password-reset email flow. Student Portal pages require a signed-in account with student role/LRN claims; Teacher Portal pages require a separately provisioned teacher role claim. Logout ends the Firebase session. Email verification proves access to the email address, not the student's identity.

Teacher Portal access is limited to Firebase accounts with a trusted teacher role claim; teacher accounts are not publicly self-registerable. However, the gradebook, roster, chat, and student records remain browser-local preview features and are not protected or synchronized by Firebase. Do not use them to store real or sensitive student records or publish them as a complete production school system.

## Production publishing and demo sandbox

The production app is in `app/`. Publish only the contents of that folder; the standalone sample-data sandbox is in the separate `demo/` folder and is not part of the production app. The production login has no demo accounts or demo shortcuts.

### Install the app for free (PWA)

The portal includes a web app manifest, install prompt, and service worker. Once deployed to an HTTPS domain (Firebase Hosting provides HTTPS), Android users can open the website in Chrome and choose **Install app** or **Add to Home screen**. On iPhone/iPad, open the site in Safari, tap **Share**, then **Add to Home Screen**. The browser decides when its install prompt is available; local `file://` previews are not installable. When rebranding, update the PWA name in `app/manifest.webmanifest` as well as the normal app branding configuration.

The service worker caches only the static app shell for faster loading. It does not cache Firebase requests, signup submissions, account details, or School ID images. Signing in, sending OTP/reset emails, and other backend services still require an internet connection; offline use shows an offline page.

For local testing, serve the repository root and open `demo/index.html`. Choose **Load Demo** to add sample sections, students, computed grades, an overdue requirement, section chat messages, student QR identity, and sample camera evidence to isolated demo storage. Open the Teacher Portal and Student Portal links from the sandbox in separate tabs; those links keep demo mode enabled. Choose **Remove Demo** to restore the sandbox's previous data. Production records use separate browser storage and are not changed by the demo.

## App name and logo

Update `app/branding-config.js` to change the app name, school name, product name, tagline, and logo path for all portal pages and the demo. Replace the image at `app/assets/logo.svg` (or point `logoPath` to a different image in `app/`) to update the logo. Use an SVG or PNG with a transparent background and square proportions for best results. The logo path is resolved relative to `branding.js`, so it works the same in both the app and demo folders. If the logo cannot load, the app name appears instead.

## Automatic grade computation

For each learner, the gradebook automatically sums activity scores and highest possible scores within WW, PT, and QA (ST plus TE), computes `PS = (student total / HPS total) × 100`, then computes `WS = PS × component weight`. The initial grade is the sum of the three weighted scores and updates whenever a score, HPS, or component weight changes. The teacher enters and decides the final Term Grade manually; it is saved per student and section and is not overwritten by recalculation. A term grade must be between 0 and 100. A score above its activity HPS is marked invalid and excluded from the initial-grade calculation. All HPS values for each component must be entered before the initial grade can be calculated.

## Term dashboards

Each section has separate Term 1, Term 2, and Term 3 gradebook dashboards. Activity counts, weights, subject, scores, due dates, and teacher-entered Term Grades are isolated by term. Existing section-only gradebook records are read as Term 1 for backward compatibility; Term 2 and Term 3 start independently.

## Printable class record

Open a section and term dashboard, edit the teacher/subject and print-header details (Region, Division, School ID, and School Year), then choose **Print Class Record**. The landscape print layout includes the active term's editable scores, initial grade, teacher-decided Term Grade, and descriptor; the input values and header metadata remain editable and are saved per term before printing.

## Deadlines, alerts, and section chat

Teachers can set a due date for each WW, PT, ST, and TE activity from a section's gradebook. Students see an in-app alert when an activity with a blank score is due within three days or overdue. Each section also has a teacher/student group chat.

Until a trusted backend is configured, deadlines, alerts, and chat messages use this browser's local storage. They do not synchronize to other devices.

### Browser permissions and integration configuration

Teacher Settings show only browser permissions: notifications and camera access for QR scanning. The app requests these permissions only after the user selects the relevant control. Firebase and EmailJS configuration are not displayed in Settings; administrator configuration remains in `app/integrations-config.js` and Firebase Function secrets.

`integrations-config.js` contains public client-side configuration fields and is included in the production app. Restrict Firebase API keys to the intended domains and use database security rules; do not treat a Firebase web API key as authorization.

### Student email verification and Firebase deployment

Student signup uses a six-digit, ten-minute OTP. The code is generated and HMAC-hashed by Firebase Cloud Functions, sent using the EmailJS OTP template, and accepted only once with a five-attempt limit and per-email/IP rate limits. The EmailJS private key and OTP HMAC secret are Firebase Function secrets; never place them in `app/` or send them in chat. The EmailJS template must use `{{passcode}}` for the code and `{{email}}` as its **To Email** recipient. Its ID is configured as `otpTemplateId`.

To deploy the secure signup flow:

1. In Firebase Console, enable **Authentication → Email/Password**, set the email action URL/template for password reset, create a **Cloud Firestore** database and a **Cloud Storage** bucket, and register a **reCAPTCHA v3** site for App Check. Add the hosted domain to both App Check's registered site domains and Firebase Authentication's authorized domains; add `localhost` to the relevant development allowlists if testing locally. Put the reCAPTCHA site key in `firebase.appCheckSiteKey` in `app/integrations-config.js`.
2. Install Node.js 20+ and the Firebase CLI, then sign in to the CLI with an account that has permission to deploy to the project selected in `.firebaserc`.
3. From the repository root, install Functions dependencies with `npm --prefix functions install`. Set the two server-only secrets using `firebase functions:secrets:set EMAILJS_PRIVATE_KEY` and `firebase functions:secrets:set OTP_HMAC_SECRET`. Use the EmailJS **private key** only in the CLI secret prompt. Generate a unique random value for the OTP HMAC secret; do not reuse a password.
4. Review `storage.rules` before deploying it, especially if the Firebase project already uses Storage. Run `firebase deploy --only functions,hosting,storage`. On first deploy, enter the EmailJS public key, service ID, and OTP template ID when Firebase prompts for the `EMAILJS_*` function parameters. Firebase stores these non-secret deployment parameters in a project-specific Functions `.env` file; do not put private values there. This command deliberately does not deploy Firestore rules; the OTP functions use the Admin SDK and do not require client Firestore access.
5. Give the trusted administrator accounts the `admin` custom claim through a secure administrative process; never let users set their own claim. Admins with suitable Firebase project permissions can review or remove images under `student-id-review/` in Firebase Storage. Establish an ID-image retention and deletion policy before real student use.
6. In EmailJS, set the OTP template's **To Email** to `{{email}}` and its message body to include `{{passcode}}`. Then sign up with an email address you control and verify the received code and that the ID image appears only to administrators.

Cloud Functions deployment requires a Firebase project with billing enabled for the required services and an account authorized to deploy; this repository cannot deploy itself without that project access. The signup flow only creates student accounts; existing Firebase accounts need trusted `role` and (for students) `lrn` custom claims to pass the student portal check. Provision teacher/admin accounts and claims separately through a trusted administrator. Email OTP proves access to the email address, not that an entered LRN belongs to a particular learner, and the image file check does not authenticate a School ID. Student records, chat, and gradebook are still local-preview data and are not synchronized to Firebase. The repository's `firestore.rules` denies all client access; review and merge it carefully before explicitly deploying those rules, especially if the project already has Firestore rules or data.

## Device notifications

Students and teachers can enable browser notifications from their Settings. Once permission is granted, the student portal can notify for due/incomplete activities and new teacher chat messages; the teacher portal can notify for student chat replies. The portal must be open in a browser tab for these local-preview notifications to run. Notifications require browser support and a secure context (HTTPS or localhost), and the user must allow permission. A `file://` preview or denied browser permission may prevent delivery.

The app includes `app/sw.js` for mobile-friendly notification display and handling incoming push events, but it does not yet create Push API subscriptions or send pushes. Notifications cannot be delivered while the browser/app is closed or synchronized to other devices by this local-storage build. Reliable background/cross-device delivery requires authenticated Firebase accounts, per-device Push API subscriptions, and a trusted server or cloud function using Web Push credentials. Do not use client-side local storage as the source of recipient authorization for real student data.

### Firebase requirements for cross-device chat

1. Create a Firebase project and register a Web app. Enable Firebase Authentication and Realtime Database.
2. Connect the app's sign-in flow to Firebase Authentication. Do not allow chat access based only on a name or role stored in local storage.
3. Store each user's section membership in a trusted database path (or custom claims) and require that membership in Realtime Database Security Rules before allowing reads or writes to that section's messages.
4. Set the `firebase` fields in `app/integrations-config.js` from the Firebase Web app settings. Never use public database rules such as `.read: true` or `.write: true` for student records or chat.

Student login uses Firebase Authentication, but the current chat is local-only and does not use Firebase. Complete trusted section membership and database rules before wiring live chat listeners; do not base authorization on local storage.

### EmailJS requirements for email alerts

1. Create an EmailJS service and a template for missing requirements.
2. Make sure student email addresses are collected and available to the authenticated teacher; imported class lists currently contain name/LRN/gender only.
3. Set the EmailJS public key, service ID, and missing-requirements template ID in `app/integrations-config.js`. Use template variables for student name, activity, section, and due date.
4. Trigger email only after the student and due activity are verified by trusted application data. Do not put EmailJS private credentials in frontend files.

Missing-requirement email alerts are not implemented. The OTP template and Cloud Function are only for student signup verification. The in-app due-date alerts work without EmailJS.